import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../data/repository.dart';
import '../widgets/ad_banner.dart';

// Ekranlar
import 'category_screen.dart';
import 'profile_screen.dart';
import 'submit_question_screen.dart';
import 'community_questions_screen.dart';

class HubScreen extends StatefulWidget {
  const HubScreen({super.key})

        ,const SizedBox(height: 8),
        // AdMob banner (real ad unit id required)
        const AdBanner(adUnitId: 'ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx'),;

  @override
  State<HubScreen> createState() => _HubScreenState();
}

class _HubScreenState extends State<HubScreen> {
  int? _coins;

  @override
  void initState() {
    super.initState();
    _loadProfileSummary();
  }

  Future<void> _loadProfileSummary() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      final profile = await DataRepository.getUserProfile(uid);

      int coins = 0;
      if (profile is Map) {
        coins = (profile['coins'] as int?) ?? 0;
      } else {
        // profil Map deÄŸilse (ileride model dÃ¶ndÃ¼rebilirsin) dinamik oku
        try {
          final dynamic p = profile;
          coins = (p.coins as int?) ?? 0;
        } catch (_) {
          coins = 0;
        }
      }

      if (!mounted) return;
      setState(() => _coins = coins);
    } catch (_) {
      // sessiz geÃ§
    }
  }

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF552583);
    const gold = Color(0xFFFDB927);

    return Scaffold(
      appBar: AppBar(
        title: const Text('QuoteHunt'),
        backgroundColor: purple,
        actions: [
          if (_coins != null)
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Row(
                children: [
                  const Text('🪙'),
                  const SizedBox(width: 6),
                  Text(
                    '$_coins',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _MenuCard(
              icon: Icons.category,
              title: 'Kategoriler',
              subtitle: 'Bir kategori seÃ§ ve oyuna baÅŸla',
              onTap: () => Navigator
                  .push(context, MaterialPageRoute(builder: (_) => const CategoryScreen()))
                  .then((_) => _loadProfileSummary()),
            ),
            _MenuCard(
              icon: Icons.person,
              title: 'Profilimm',
              subtitle: 'SkorlarÄ±m ve bakiyem',
              onTap: () => Navigator
                  .push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()))
                  .then((_) => _loadProfileSummary()),
            ),
            _MenuCard(
              icon: Icons.edit,
              title: 'Bize Soru Yaz',
              subtitle: 'AlÄ±ntÄ±, ipucu ve cevap gÃ¶nder',
              onTap: () => Navigator
                  .push(context, MaterialPageRoute(builder: (_) => const SubmitQuestionScreen()))
                  .then((_) => _loadProfileSummary()),
            ),
            _MenuCard(
              icon: Icons.people_alt,
              title: 'Topluluk SorularÄ±',
              subtitle: 'Kategori seÃ§ ve soru gÃ¶nder',
              onTap: () => Navigator
                  .push(context, MaterialPageRoute(builder: (_) => const CommunityQuestionsScreen()))
                  .then((_) => _loadProfileSummary()),
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;

  const _MenuCard({
    required this.icon,
    required this.title,
    required this.onTap,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFFDB927);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: gold,
          child: Icon(icon, color: Colors.black87),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: subtitle != null ? Text(subtitle!) : null,
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}

