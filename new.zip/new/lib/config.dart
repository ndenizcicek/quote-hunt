/// Global app configuration constants.
library config;

/// Per-question countdown seconds.
const int kQuestionSeconds = 30;

