import 'package:flutter_test/flutter_test.dart';

// Pubspec'teki package adÄ±nla main.dart'Ä± import et.
// Ã–rn: pubspec.yaml -> name: quote_hunt_new ise:

void main() {
  testWidgets('App boots and shows Firebase init text', (WidgetTester tester) async {
    
    // Ekranda Firebase ile ilgili bir metin gÃ¶rmeyi bekliyoruz
    expect(find.textContaining('Firebase'), findsOneWidget);
  });
}

