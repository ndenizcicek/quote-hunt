import 'package:flutter/material.dart';
import 'submit_question_screen.dart';
import 'community_questions_screen.dart';

class SubmitMenuScreen extends StatelessWidget {
  const SubmitMenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bize Soru Yaz')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              child: ListTile(
                leading: const Icon(Icons.edit),
                title: const Text('Bize Soru Yaz (GÃ¶nder)'),
                subtitle: const Text('Soru ve cevabÄ±nÄ± gÃ¶nder, onay sonrasÄ± oyuna ekleyelim'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const SubmitQuestionScreen()));
                },
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.forum),
                title: const Text('Topluluk SorularÄ±'),
                subtitle: const Text('OyuncularÄ±n yazdÄ±klarÄ±nÄ± gÃ¶rÃ¼ntÃ¼le (yakÄ±nda)'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const CommunityQuestionsScreen()));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

