import 'package:firebase_auth/firebase_auth.dart';
ï»¿import 'package:flutter/material.dart';
import '../data/repository.dart';
import '../data/models.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
    final repo = DataRepository();

  Map<String, int> scores = {};
  List<Category> categories = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final cats = await repo.getCategories();
      final uid = FirebaseAuth.instance.currentUser?.uid;
      Map<String,int> map = {};
      if (uid != null) {
        final profile = await DataRepository.getUserProfile(uid);
        final hs = Map<String, dynamic>.from(profile['highscores'] ?? {});
        map = hs.map((k,v)=> MapEntry(k, (v as num).toInt()));
      }
      setState(() {
        categories = cats;
        scores = map;
        loading = false;
      });
    } catch (_) {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profilim')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: categories.length,
              itemBuilder: (_, i) {
                final c = categories[i];
                final s = scores[c.id] ?? 0;
                return Card(
                  child: ListTile(
                    title: Text(c.name),
                    trailing: Text('$s', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                );
              },
            ),
    );
  }
}

