import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../data/repository.dart';

class SubmitQuestionScreen extends StatefulWidget {
  const SubmitQuestionScreen({super.key});

  @override
  State<SubmitQuestionScreen> createState() => _SubmitQuestionScreenState();
}

class _SubmitQuestionScreenState extends State<SubmitQuestionScreen> {
  final _formKey = GlobalKey<FormState>();

  final _catCtrl = TextEditingController();
  final _quoteCtrl = TextEditingController();
  final _hintCtrl = TextEditingController();
  final _answerCtrl = TextEditingController();

  bool _sending = false;

  @override
  void dispose() {
    _catCtrl.dispose();
    _quoteCtrl.dispose();
    _hintCtrl.dispose();
    _answerCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('GiriÅŸ gerekli.')),
      );
      return;
    }

    setState(() => _sending = true);
    try {
      await DataRepository.submitCommunityQuestion(
        uid: uid,
        categoryId: _catCtrl.text.trim().isEmpty ? 'general' : _catCtrl.text.trim(),
        quote: _quoteCtrl.text.trim(),
        hint: _hintCtrl.text.trim(),
        answer: _answerCtrl.text.trim(),
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gönderildi! Ä°ncelemeye alÄ±ndÄ±.')),
      );
      _quoteCtrl.clear();
      _hintCtrl.clear();
      _answerCtrl.clear();
      // kategoriyi istersen temizleme: _catCtrl.clear();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Hata: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF552583);

    return Scaffold(
      appBar: AppBar(title: const Text('Soru Gönder')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: ListView(
              children: [
                TextFormField(
                  controller: _catCtrl,
                  validator: (v) => (v==null||v.trim().isEmpty)?'Zorunlu':null,
                  decoration: const InputDecoration(
                    labelText: 'Kategori (örn: sport, philosophy)',
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _quoteCtrl,
                  validator: (v) => (v==null||v.trim().isEmpty)?'Zorunlu':null,
                  decoration: const InputDecoration(labelText: 'AlÄ±ntÄ±'),
                  maxLines: null,
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Zorunlu' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _hintCtrl,
                  decoration: const InputDecoration(labelText: 'İpucu'),
                  maxLines: null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _answerCtrl,
                  decoration: const InputDecoration(labelText: 'Cevap'),
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Zorunlu' : null,
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: _sending ? null : _submit,
                  icon: const Icon(Icons.send),
                  label: Text(_sending ? 'Gönderiliyor…' : 'Gönder'),
                  style: ElevatedButton.styleFrom(backgroundColor: purple),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

