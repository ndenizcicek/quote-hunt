import 'dart:ui' as ui;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'models.dart';

class DataRepository {

static DatabaseReference _db() {
    const dbUrl = 'https://quotehuntgame-default-rtdb.europe-west1.firebasedatabase.app';
    return FirebaseDatabase.instanceFor(
      app: Firebase.app(),
      databaseURL: dbUrl,
    ).ref();
  }

  // RTDB URL
  static const String kDbUrl =
      'https://quotehuntgame-default-rtdb.europe-west1.firebasedatabase.app';

  Box get _box => Hive.box('qh_cache');

  /* ----------------------------- Helpers ----------------------------- */

  static DatabaseReference _root() => FirebaseDatabase.instanceFor(
        app: Firebase.app(),
        databaseURL: kDbUrl,
      ).ref();

  static String _slugify(String s) {
    final lower = s.trim().toLowerCase();
    final onlyAscii = lower
        .replaceAll(RegExp(r'[^\x00-\x7F]'), '')
        .replaceAll(RegExp(r'[^a-z0-9]+'), '-')
        .replaceAll(RegExp(r'-+'), '-')
        .replaceAll(RegExp(r'^-|-$'), '');
    return onlyAscii.isEmpty ? 'general' : onlyAscii;
  }

  static String currentLang() {
    final code = ui.PlatformDispatcher.instance.locale.languageCode.toLowerCase();
    if (code == 'tr' || code == 'es' || code == 'en') return code;
    return 'en';
  }

  String get _preferredLang {
    final fromBox = (_box.get('lang') as String?)?.toLowerCase();
    if (fromBox != null && fromBox.isNotEmpty) return fromBox;
    return currentLang();
  }

  void setPreferredLanguage(String code) {
    _box.put('lang', code.toLowerCase());
  }

  /* ---------------------------- Categories --------------------------- */

  Future<List<Category>> getCategories() async {
    final cached = _box.get('categories:list');
    if (cached is List) {
      final list = cached
          .cast<Map>()
          .map((e) => Category.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      _refreshCategoriesSilently();
      return list;
    }

    final list = await _fetchCategoriesFromRTDB();
    if (list.isEmpty) {
      throw Exception(
          'No categories found. Put data under /categories or /questions.');
    }
    _box.put('categories:list', list.map((e) => e.toJson()).toList());
    return list;
  }

  Future<void> _refreshCategoriesSilently() async {
    try {
      final fresh = await _fetchCategoriesFromRTDB();
      if (fresh.isNotEmpty) {
        _box.put('categories:list', fresh.map((e) => e.toJson()).toList());
      }
    } catch (_) {}
  }

  Future<List<Category>> _fetchCategoriesFromRTDB() async {
    final db = FirebaseDatabase.instanceFor(
      app: Firebase.app(),
      databaseURL: kDbUrl,
    );

    // 1) /categories
    final catSnap = await db.ref('categories').get();
    if (catSnap.exists && catSnap.value != null) {
      final out = <Category>[];
      final v = catSnap.value;
      if (v is List) {
        for (final item in v) {
          if (item == null) continue;
          final m = Map<String, dynamic>.from(item as Map);
          final name = (m['name'] ?? m['title'] ?? '').toString();
          if (name.isEmpty) continue;
          final id = (m['id']?.toString() ?? _slugify(name));
          out.add(Category(id: id, name: name));
        }
        if (out.isNotEmpty) return out;
      } else if (v is Map) {
        final m = Map<String, dynamic>.from(v as Map);
        m.forEach((key, val) {
          final mm = Map<String, dynamic>.from(val as Map);
          final name = (mm['name'] ?? mm['title'] ?? key).toString();
          final id = _slugify(mm['id']?.toString() ?? key.toString());
          out.add(Category(id: id, name: name));
        });
        if (out.isNotEmpty) return out;
      }
    }

    // 2) /questionsâ€™tan tÃ¼ret
    final qSnap = await db.ref('questions').get();
    final out = <Category>[];
    if (qSnap.exists && qSnap.value != null) {
      if (qSnap.value is Map) {
        final m = Map<String, dynamic>.from(qSnap.value as Map);
        for (final key in m.keys) {
          final id = _slugify(key);
          out.add(Category(
              id: id,
              name: id
                  .split('-')
                  .map((p) => p[0].toUpperCase() + p.substring(1))
                  .join(' ')));
        }
        if (out.isNotEmpty) return out;
      } else if (qSnap.value is List) {
        final l = (qSnap.value as List).where((e) => e != null).cast<Map>();
        final set = <String>{};
        for (final e in l) {
          final mm = Map<String, dynamic>.from(e);
          final cat = (mm['category'] ?? '').toString();
          if (cat.isNotEmpty) set.add(_slugify(cat));
        }
        for (final id in set) {
          out.add(Category(
              id: id,
              name: id
                  .split('-')
                  .map((p) => p[0].toUpperCase() + p.substring(1))
                  .join(' ')));
        }
        if (out.isNotEmpty) return out;
      }
    }
    return out;
  }

  /* ------------------------------ Quotes ----------------------------- */

  Future<List<QuoteItem>> getQuotes(String categoryId, int page) async {
    const pageSize = 10;
    final lang = _preferredLang;
    final key = 'quotes:$categoryId:$page:$lang';

    final cached = _box.get(key);
    if (cached is List) {
      return cached
          .cast<Map>()
          .map((e) => QuoteItem.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    final allMaps = await _fetchAllQuoteMapsForCategory(categoryId);
    final resolved = allMaps.map((m) => _toQuoteItemWithLang(m, lang)).toList();

    final start = (page - 1) * pageSize;
    if (start >= resolved.length) return [];
    final end =
        (start + pageSize > resolved.length) ? resolved.length : (start + pageSize);
    final slice = resolved.sublist(start, end);

    _box.put(key, slice.map((e) => e.toJson()).toList());
    return slice;
  }

  Future<List<Map<String, dynamic>>> _fetchAllQuoteMapsForCategory(
      String categoryId) async {
    final db = FirebaseDatabase.instanceFor(
      app: Firebase.app(),
      databaseURL: kDbUrl,
    );

    // 1) /questions/{categoryId}
    final snap1 = await db.ref('questions/$categoryId').get();
    if (snap1.exists && snap1.value != null) {
      final v = snap1.value;
      final items = <Map<String, dynamic>>[];
      if (v is List) {
        for (final e in v) {
          if (e == null) continue;
          items.add(Map<String, dynamic>.from(e as Map));
        }
      } else if (v is Map) {
        final m = Map<String, dynamic>.from(v as Map);
        m.forEach((_, val) {
          if (val == null) return;
          items.add(Map<String, dynamic>.from(val as Map));
        });
      }
      return items;
    }

    // 2) dÃ¼z liste
    final snap2 = await db.ref('questions').get();
    if (snap2.exists && snap2.value != null) {
      final items = <Map<String, dynamic>>[];
      if (snap2.value is List) {
        for (final e in (snap2.value as List)) {
          if (e == null) continue;
          final mm = Map<String, dynamic>.from(e as Map);
          final cat = (mm['category'] ?? '').toString();
          if (_slugify(cat) == _slugify(categoryId)) items.add(mm);
        }
      } else if (snap2.value is Map) {
        final m = Map<String, dynamic>.from(snap2.value as Map);
        for (final entry in m.values) {
          if (entry is Map) {
            final mm = Map<String, dynamic>.from(entry);
            final cat = (mm['category'] ?? '').toString();
            if (_slugify(cat) == _slugify(categoryId)) items.add(mm);
          }
        }
      }
      return items;
    }
    return [];
  }

  QuoteItem _toQuoteItemWithLang(Map<String, dynamic> src, String lang) {
    String pick(dynamic v) {
      if (v is String) return v;
      if (v is Map) {
        final mm = Map<String, dynamic>.from(v);
        return (mm[lang] ??
                mm['en'] ??
                (mm.values.isNotEmpty ? mm.values.first : ''))
            .toString();
      }
      return '';
    }

    return QuoteItem.fromJson({
      'quote': pick(src['quote']),
      'hint': pick(src['hint']),
      'answer': (src['answer'] ?? '').toString(),
    });
  }

  /* -------------------------- User Profile --------------------------- */

  static DatabaseReference _userRef(String uid) => _root().child('users/$uid');

  static Future<void> ensureUserProfile(String uid) async {
    final ref = _userRef(uid);
    final snap = await ref.get();
    if (!snap.exists || snap.value == null) {
      await ref.set({
        'createdAt': ServerValue.timestamp,
        'lastSeen': ServerValue.timestamp,
        'coins': 100,
        'highscores': {}
      });
      return;
    }
    final cur = Map<String, dynamic>.from(snap.value as Map);
    final updates = <String, dynamic>{'lastSeen': ServerValue.timestamp};
    if (cur['coins'] == null) updates['coins'] = 100;
    if (cur['highscores'] == null) updates['highscores'] = {};
    await ref.update(updates);
  }

  static Future<Map<String, dynamic>> getUserProfile(String uid) async {
    final snap = await _userRef(uid).get();
    if (!snap.exists || snap.value == null) {
      return {'coins': 0, 'highscores': <String, dynamic>{}};
    }
    final m = Map<String, dynamic>.from(snap.value as Map);
    return {
      'coins': (m['coins'] ?? 0) as int,
      'highscores': Map<String, dynamic>.from(m['highscores'] ?? {}),
      'createdAt': m['createdAt'],
      'lastSeen': m['lastSeen'],
    };
  }

  static Future<int> updateHighscoreIfBest(
      String uid, String categoryId, int score) async {
    final hsRef = _userRef(uid).child('highscores/$categoryId');
    final result = await hsRef.runTransaction((current) {
      final cur = (current is int) ? current : 0;
      final best = (score > cur) ? score : cur;
      return Transaction.success(best);
    });
    final val = result.snapshot.value;
    return (val is int) ? val : score;
  }

  static Future<int> addCoins(String uid, int delta) async {
    final coinsRef = _userRef(uid).child('coins');
    final result = await coinsRef.runTransaction((current) {
      final cur = (current is int) ? current : 0;
      final next = cur + delta;
      return Transaction.success(next < 0 ? 0 : next);
    });
    final val = result.snapshot.value;
    return (val is int) ? val : 0;
  }

  /* --------------------- Community Submissions ----------------------- */

  // â€¦ dosyanÄ±n mevcut iÃ§eriÄŸi aynÄ± kalsÄ±n â€¦
// AÅAÄISI YENÄ° EKLEDÄ°ÄÄ°M BÃ–LÃœM

  /* --------------------- Community Submissions ----------------------- */
  /// KullanÄ±cÄ±nÄ±n gÃ¶nderdiÄŸi sorularÄ± RTDB'ye bÄ±rakÄ±r.
  /// /community_submissions/{autoId} altÄ±nda saklanÄ±r.
  static Future<void> submitCommunityQuestion({
    required String uid,
    required String categoryId, // serbest metin olabilir; admin sluga dÃ¶nÃ¼ÅŸtÃ¼rÃ¼r
    required String quote,
    required String hint,
    required String answer,
  }) async {
    final ref = _db().child('community_submissions').push();
    await ref.set({
      'uid': uid,
      'category': categoryId,
      'quote': quote,
      'hint': hint,
      'answer': answer,
      'createdAt': ServerValue.timestamp,
      'status': 'pending',
    });
  }
}

