import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../data/models.dart';
import '../data/repository.dart';

class CommunityQuestionsScreen extends StatefulWidget {
  const CommunityQuestionsScreen({super.key});

  @override
  State<CommunityQuestionsScreen> createState() => _CommunityQuestionsScreenState();
}

class _CommunityQuestionsScreenState extends State<CommunityQuestionsScreen> {
  final _repo = DataRepository();
  bool _loading = true;
  List<Category> _cats = [];
  Category? _selected;

  // form
  final _formKey = GlobalKey<FormState>();
  final _quoteCtrl = TextEditingController();
  final _hintCtrl = TextEditingController();
  final _answerCtrl = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _quoteCtrl.dispose();
    _hintCtrl.dispose();
    _answerCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final list = await _repo.getCategories();
      if (!mounted) return;
      setState(() {
        _cats = list;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Load error: $e')));
    }
  }

  Future<void> _submitForSelected() async {
    if (_selected == null) return;
    if (!_formKey.currentState!.validate()) return;

    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('GiriÅŸ gerekli.')));
      return;
    }

    setState(() => _sending = true);
    try {
      await DataRepository.submitCommunityQuestion(
        uid: uid,
        categoryId: _selected!.id,
        quote: _quoteCtrl.text.trim(),
        hint: _hintCtrl.text.trim(),
        answer: _answerCtrl.text.trim(),
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('GÃ¶nderildi! Ä°ncelemeye alÄ±ndÄ±.')),
      );
      _quoteCtrl.clear();
      _hintCtrl.clear();
      _answerCtrl.clear();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Hata: $e')));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF552583);

    return Scaffold(
      appBar: AppBar(
        title: Text(_selected == null ? 'Topluluk SorularÄ±' : _selected!.name),
        leading: _selected == null
            ? null
            : IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => setState(() => _selected = null),
              ),
      ),
      body: _selected == null ? _buildCategoryList() : _buildForm(purple),
    );
  }

  Widget _buildCategoryList() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_cats.isEmpty) return const Center(child: Text('Kategori bulunamadÄ±.'));
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _cats.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) {
        final c = _cats[i];
        return Card(
          child: ListTile(
            title: Text(c.name),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => setState(() => _selected = c),
          ),
        );
      },
    );
  }

  Widget _buildForm(Color purple) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              // Kategori alanÄ± YOK â€“ seÃ§ili kategori AppBar baÅŸlÄ±ÄŸÄ±nda gÃ¶rÃ¼nÃ¼yor.
              TextFormField(
                controller: _quoteCtrl,
                decoration: const InputDecoration(labelText: 'AlÄ±ntÄ±'),
                maxLines: null,
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Zorunlu' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _hintCtrl,
                decoration: const InputDecoration(labelText: 'Ä°pucu'),
                maxLines: null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _answerCtrl,
                decoration: const InputDecoration(labelText: 'Cevap'),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Zorunlu' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _sending ? null : _submitForSelected,
                icon: const Icon(Icons.send),
                label: Text(_sending ? 'GÃ¶nderiliyorâ€¦' : 'GÃ¶nder'),
                style: ElevatedButton.styleFrom(backgroundColor: purple),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

