import 'package:hive_flutter/hive_flutter.dart';

class HighscoreStore {
  HighscoreStore() : _box = Hive.box('qh_cache');
  final Box _box;

  /// kategori bazlÄ± en yÃ¼ksek skor
  int getHighscore(String categoryId) {
    return _box.get('hs:$categoryId', defaultValue: 0) as int;
  }

  /// set if greater
  void setIfHigher(String categoryId, int newScore) {
    final current = getHighscore(categoryId);
    if (newScore > current) {
      _box.put('hs:$categoryId', newScore);
    }
  }

  /// tÃ¼m skorlarÄ± getir (profil iÃ§in)
  Map<String, int> getAll() {
    final out = <String, int>{};
    for (final k in _box.keys) {
      if (k is String && k.startsWith('hs:')) {
        out[k.substring(3)] = _box.get(k) as int;
      }
    }
    return out;
  }
}

