import 'package:google_mobile_ads/google_mobile_ads.dart';
ï»¿
import 'dart:developer' as dev;
import 'package:firebase_auth/firebase_auth.dart' show FirebaseAuth, Persistence, User;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'firebase_options.dart';
import 'config.dart';
import 'data/repository.dart';
import 'screens/hub_screen.dart';

Future<User> _getOrCreateAnonUser() async {
  final auth = FirebaseAuth.instance;
  try {
    final restored = await auth.authStateChanges().first;
    if (restored != null) return restored;
  } catch (_) {
    final existing = auth.currentUser;
    if (existing != null) return existing;
  }
  final cred = await auth.signInAnonymously();
  return cred.user!;
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox('qh_cache');

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  // Initialize Google Mobile Ads
  await MobileAds.instance.initialize();
  try {
    await FirebaseAuth.instance.setPersistence(Persistence.LOCAL);
  } catch (e, st) {
    dev.log('setPersistence failed: $e', stackTrace: st);
  }

  final user = await _getOrCreateAnonUser();
  dev.log("UID: ${user.uid}");

  // Ensure RTDB user profile exists and bump lastSeen.
  try {
    await DataRepository.ensureUserProfile(user.uid);
  } catch (e, st) {
    dev.log("ensureUserProfile failed: $e", stackTrace: st);
  }

  // Optional sanity read
  try {
    const dbUrl = 'https://quotehuntgame-default-rtdb.europe-west1.firebasedatabase.app';
    final db = FirebaseDatabase.instanceFor(app: Firebase.app(), databaseURL: dbUrl);
    await db.ref('questions').limitToFirst(1).get();
  } catch (_) {}

  runApp(const QuoteHuntApp());
}

class QuoteHuntApp extends StatelessWidget {
  const QuoteHuntApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QuoteHunt',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF552583)),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 800), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HubScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    const lakersPurple = Color(0xFF552583);
    return Scaffold(
      backgroundColor: lakersPurple,
      body: const SafeArea(
        child: Center(
          child: Image(
            image: AssetImage('assets/dart_emoji.png'),
            width: 120, height: 120,
          ),
        ),
      ),
    );
  }
}

