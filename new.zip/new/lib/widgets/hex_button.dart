import 'package:flutter/material.dart';

class HexButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool used;
  final bool revealed; // <- opsiyonel olacak

  const HexButton({
    super.key,
    required this.label,
    required this.onTap,
    required this.used,
    this.revealed = false, // <- default false
  });

  @override
  Widget build(BuildContext context) {
    final baseColor = used
        ? Colors.grey.shade400
        : (revealed ? Colors.grey.shade300 : const Color(0xFFFDB927)); // Lakers gold
    final txtColor = used || revealed ? Colors.black54 : Colors.black87;

    return Material(
      color: baseColor,
      shape: const _HexShapeBorder(),
      child: InkWell(
        customBorder: const _HexShapeBorder(),
        onTap: onTap,
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: txtColor,
            ),
          ),
        ),
      ),
    );
  }
}

class _HexShapeBorder extends ShapeBorder {
  const _HexShapeBorder();

  @override
  EdgeInsetsGeometry get dimensions => EdgeInsets.zero;

  @override
  Path getOuterPath(Rect rect, {TextDirection? textDirection}) {
    final w = rect.width;
    final h = rect.height;
    return Path()
      ..moveTo(rect.left + w * 0.25, rect.top)
      ..lineTo(rect.left + w * 0.75, rect.top)
      ..lineTo(rect.right, rect.top + h * 0.5)
      ..lineTo(rect.left + w * 0.75, rect.bottom)
      ..lineTo(rect.left + w * 0.25, rect.bottom)
      ..lineTo(rect.left, rect.top + h * 0.5)
      ..close();
  }

  @override
  void paint(Canvas canvas, Rect rect, {TextDirection? textDirection}) {}

  @override
  ShapeBorder scale(double t) => this;

  @override
  Path getInnerPath(Rect rect, {TextDirection? textDirection}) => getOuterPath(rect);
}

