package com.example.quote_hunt_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
