import '../config.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/models.dart';
import '../data/repository.dart';
import '../widgets/hex_button.dart';

class QuizScreen extends StatefulWidget {
  final Category category;
  const QuizScreen({super.key, required this.category});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  
Future<void> _loadProfileCoins() async {
  final uid = FirebaseAuth.instance.currentUser?.uid;
  if (uid == null) return;
  try {
    final profile = await DataRepository.getUserProfile(uid);
    final int serverCoins = (profile['coins'] ?? 0) as int;
    if (mounted) setState(() => coins = serverCoins);
  } catch (_) {}
}

  Future<void> _applyCoinDelta(int delta) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      await DataRepository.addCoins(uid, delta);
    } catch (_) {}
  }

  final repo = DataRepository();
  final rnd = math.Random();

  // paging + buffer
  int page = 1;
  final List<QuoteItem> _buffer = [];
  bool loading = true;
  bool reachedEnd = false;

  // answered cache
  late final Box cacheBox;
  late Set<String> answeredSet;

  // quiz state
  int currentIndex = 0;
  int score = 0;
  int coins = 0;
  int hintsAvailable = 3;

  // timer
  static const int kSeconds = kQuestionSeconds;
  int secondsLeft = kSeconds;
  bool _timerRunning = false;

  // answer state
  String correctAnswer = '';
  String currentAnswer = '';
  List<String> availableLetters = [];
  List<int> usedIndices = [];
  List<String?> revealedMap = []; // ' ' ya da harf ya da null

  // hint ile gri gÃ¶sterilecek petekler
  final Set<int> revealedHoneyIndices = {};

  @override
  void initState() {
    super.initState();
    cacheBox = Hive.box('qh_cache');
    answeredSet =
        (cacheBox.get('answered_set') as List?)?.cast<String>().toSet() ?? {};
    _loadPage(page);
    _loadProfileCoins();
  }

  Future<void> _loadPage(int p) async {
    try {
      setState(() => loading = true);
      final items = await repo.getQuotes(widget.category.id, p);
      if (items.isEmpty) {
        setState(() {
          reachedEnd = true;
          loading = false;
        });
        return;
      }
      final filtered = items.where((q) => !_isAnswered(_qidFor(q))).toList();

      setState(() {
        _buffer.addAll(filtered);
        loading = false;
      });
      if (p == 1) _setupQuestion();
    } catch (_) {
      setState(() {
        reachedEnd = true;
        loading = false;
      });
    }
  }

  String _qidFor(QuoteItem q) => '${widget.category.id}|${q.quote}';
  bool _isAnswered(String id) => answeredSet.contains(id);

  void _markAnswered(QuoteItem q) {
    final id = _qidFor(q);
    answeredSet.add(id);
    cacheBox.put('answered_set', answeredSet.toList());
  }

  void _setupQuestion() {
    if (_buffer.isEmpty) return;

    while (currentIndex < _buffer.length &&
        _isAnswered(_qidFor(_buffer[currentIndex]))) {
      currentIndex++;
    }
    if (currentIndex >= _buffer.length) {
      _goNextOrFinish();
      return;
    }

    final q = _buffer[currentIndex];
    correctAnswer = q.answer.toUpperCase();
    currentAnswer = '';
    usedIndices = [];
    hintsAvailable = 3;
    secondsLeft = kSeconds;
    revealedMap =
        correctAnswer.split('').map((ch) => ch == ' ' ? ' ' : null).toList();
    revealedHoneyIndices.clear();

    final freqLetters = correctAnswer.replaceAll(' ', '').split('');
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    final used = {...freqLetters};

    final distractors = <String>[];
    while (distractors.length < 3) {
      final l = alphabet[rnd.nextInt(alphabet.length)];
      if (!used.contains(l) && !distractors.contains(l)) distractors.add(l);
    }

    availableLetters = [...freqLetters, ...distractors]..shuffle();
    setState(() {});
    _startTimer();
  }

  void _startTimer() {
    _timerRunning = true;
    _tick();
  }

  Future<void> _tick() async {
    while (mounted && _timerRunning && secondsLeft > 0) {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted || !_timerRunning) return;
      setState(() => secondsLeft--);
    }
    if (mounted && secondsLeft == 0) {
      _timerRunning = false;
      _onTimeUp();
    }
  }

  void _stopTimer() {
    _timerRunning = false;
  }

  void _onTimeUp() {
    final q = _buffer[currentIndex];
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('â° Timeâ€™s up!'),
        content: const Text('Choose an option:'),
        actions: [
          TextButton(
            onPressed: coins >= 20
                ? () async {
              Navigator.pop(context);
                    _showAnswerPurchase(fromTimeout: true);
                  }
                : null,
            child: const Text('Show Answer (20)'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              _simulateLongAd(() {
                _markAnswered(q);
                _goNextOrFinish();
              });
            },
            child: const Text('Watch long ad & skip'),
          ),
        ],
      ),
    );
  }

  void _simulateLongAd(VoidCallback onDone) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _AdOverlay(seconds: 5),
    );
    Future.delayed(const Duration(seconds: 5), () {
      Navigator.of(context, rootNavigator: true).pop();
      onDone();
    });
  }

  void _selectLetter(int idx) {
    if (usedIndices.contains(idx)) return;
    setState(() {
      usedIndices.add(idx);
      currentAnswer += availableLetters[idx];
    });
  }

  void _clearAnswer() {
    setState(() {
      currentAnswer = '';
      usedIndices.clear();
    });
  }

  void _backspace() {
    if (currentAnswer.isEmpty || usedIndices.isEmpty) return;
    setState(() {
      currentAnswer = currentAnswer.substring(0, currentAnswer.length - 1);
      usedIndices.removeLast();
    });
  }

  void _useHint() {
    if (hintsAvailable > 0) {
      _revealOneLetter();
      setState(() => hintsAvailable--);
      return;
    }
    _showHintDepletedDialog();
  }

  void _revealOneLetter() {
    final ans = correctAnswer.split('');
    final missing = <int>[];
    for (var i = 0; i < ans.length; i++) {
      if (ans[i] != ' ' && revealedMap[i] == null) missing.add(i);
    }
    if (missing.isEmpty) return;

    final pos = missing[rnd.nextInt(missing.length)];
    final letter = ans[pos];

    setState(() {
      revealedMap[pos] = letter;
      for (int j = 0; j < availableLetters.length; j++) {
        if (!usedIndices.contains(j) &&
            !revealedHoneyIndices.contains(j) &&
            availableLetters[j] == letter) {
          revealedHoneyIndices.add(j);
          break;
        }
      }
    });
  }

  void _showHintDepletedDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('No hints left'),
        content:
            const Text('Watch a short ad to get +1 hint, or buy a hint for 10 coins.'),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              _simulateLongAd(() {
                setState(() => hintsAvailable = 1);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('ğŸ‰ +1 hint granted!')),
                );
              });
            },
            child: const Text('ğŸ“º Watch Ad'),
          ),
          TextButton(
            onPressed: coins >= 10
                ? () async {
              Navigator.pop(context);
                    setState(() { coins -= 10;  hintsAvailable = 1;
                      });
      _applyCoinDelta(-10);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('🪙 10 coins → +1 hint')),
                    );
                  }
                : null,
            child: const Text('Satın al (10🪙)'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  String _formedAnswerForDisplay() {
    final ans = correctAnswer.split('');
    final typed = currentAnswer.split('');
    var t = 0;
    final out = StringBuffer();
    for (var i = 0; i < ans.length; i++) {
      if (ans[i] == ' ') {
        out.write(' ');
        continue;
      }
      final revealed = revealedMap[i];
      if (revealed != null && revealed != ' ') {
        out.write(revealed);
      } else {
        if (t < typed.length) {
          out.write(typed[t++]);
        } else {
          out.write('_');
        }
      }
    }
    return out.toString();
  }

  String _composedAnswerNoSpaces() {
    final ans = correctAnswer.split('');
    final typed = currentAnswer.split('');
    var t = 0;
    final out = StringBuffer();
    for (var i = 0; i < ans.length; i++) {
      if (ans[i] == ' ') continue;
      final revealed = revealedMap[i];
      if (revealed != null && revealed != ' ') {
        out.write(revealed);
      } else {
        if (t < typed.length) {
          out.write(typed[t++]);
        } else {
          out.write('_');
        }
      }
    }
    return out.toString().replaceAll(' ', '');
  }

  void _submit() {
    if (_composedAnswerNoSpaces().trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Önce bir cevap yaz.')),
      );
      return;
    }

    String normalize(String s) => s.replaceAll(' ', '').toUpperCase();
    final isCorrect =
        normalize(_composedAnswerNoSpaces()) == normalize(correctAnswer);

    final q = _buffer[currentIndex];
    if (isCorrect) {
      setState(() { score += 1;
        coins += 5;   });
      _applyCoinDelta(5);
      _stopTimer();
      _markAnswered(q);
    } else {
      _stopTimer();
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text(isCorrect ? 'ğŸ‰ Correct! +5 🪙' : 'âŒ Wrong'),
        content: Text('Quote by ${q.answer}'),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              _goNextOrFinish();
            },
            child: const Text('Next'),
          ),
        ],
      ),
    );
  }

  void _goNextOrFinish() async {
    if (currentIndex < _buffer.length - 1) {
      setState(() => currentIndex++);
      _setupQuestion();
      return;
    }
    if (!reachedEnd) {
      page++;
      await _loadPage(page);
    _loadProfileCoins();
      if (!reachedEnd && currentIndex < _buffer.length - 1) {
        setState(() => currentIndex++);
        _setupQuestion();
        return;
      }
    }
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) { try { await DataRepository.updateHighscoreIfBest(uid, widget.category.id, score); } catch (_) {} }
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ResultScreen(score: score, total: _buffer.length),
      ),
    );
  }

  void _showAnswerPurchase({bool fromTimeout = false}) {
    final q = _buffer[currentIndex];

    if (coins < 20) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Yeterli coin yok (need 20).')),
      );
      return;
    }
    setState(() { coins -= 20;  revealedMap = correctAnswer.split('').map((_) => null).toList();
      revealedMap =
          correctAnswer.split('').map((ch) => ch == ' ' ? ' ' : ch).toList(growable: false);
      });
      _applyCoinDelta(-20);

    _stopTimer();
    _markAnswered(q);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('✅ Cevap gösterildi (âˆ’20 🪙)'),
        content: Text('Answer: $correctAnswer'),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              _goNextOrFinish();
            },
            child: const Text('Next'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const lakersGold = Color(0xFFFDB927);

    if (loading && _buffer.isEmpty) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_buffer.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.category.name)),
        body: const Center(child: Text('No questions.')),
      );
    }

    final formed = _formedAnswerForDisplay();
    final q = _buffer[currentIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.category.name),
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  const Text('â³'),
                  const SizedBox(width: 4),
                  Text('$secondsLeft', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(width: 16),
                  const Text('🪙'),
                  const SizedBox(width: 4),
                  Text('$coins', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(width: 16),
                  const Text('Score:'),
                  const SizedBox(width: 4),
                  Text('$score', style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Card(
                elevation: 1,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    q.quote,
                    style: const TextStyle(fontSize: 18),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  formed.isEmpty ? '_' : formed,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 20, letterSpacing: 1.5, fontWeight: FontWeight.w600),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _useHint,
                      icon: const Icon(Icons.lightbulb),
                      label: Text('Hint ($hintsAvailable)'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: hintsAvailable > 0 ? lakersGold : Colors.grey.shade400,
                        foregroundColor: Colors.black87,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: coins >= 20 ? () => _showAnswerPurchase() : null,
                      icon: const Icon(Icons.visibility),
                      label: const Text('Show Answer (20)'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    const cross = 6;
                    const spacing = 8.0;
                    final itemW = (constraints.maxWidth - spacing * (cross - 1)) / cross;
                    final itemH = itemW;
                    return GridView.builder(
                      itemCount: availableLetters.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: cross,
                        mainAxisSpacing: spacing,
                        crossAxisSpacing: spacing,
                        childAspectRatio: itemW / itemH,
                      ),
                      itemBuilder: (context, i) {
                        final used = usedIndices.contains(i);
                        final letter = availableLetters[i];
                        final isRevealedVisual = revealedHoneyIndices.contains(i);
                        return SizedBox(
                          width: itemW,
                          height: itemH,
                          child: HexButton(
                            label: letter,
                            onTap: used ? null : () => _selectLetter(i),
                            used: used,
                            revealed: !used && isRevealedVisual,
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _clearAnswer,
                      child: const Text('Clear'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _backspace,
                      child: const Text('Backspace'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _submit,
                      child: const Text('Submit'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/* ------------------------------- AD OVERLAY ------------------------------- */

class _AdOverlay extends StatefulWidget {
  final int seconds;
  const _AdOverlay({required this.seconds});
  @override
  State<_AdOverlay> createState() => _AdOverlayState();
}

class _AdOverlayState extends State<_AdOverlay> {
  late int left;
  @override
  void initState() {
    super.initState();
    left = widget.seconds;
    _tick();
  }

  void _tick() async {
    while (mounted && left > 0) {
      await Future.delayed(const Duration(seconds: 1));
      setState(() => left--);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.black87,
      insetPadding: const EdgeInsets.all(32),
      child: SizedBox(
        height: 180,
        child: Center(
          child: Text(
            'ğŸ“º Watching Adâ€¦ $left',
            style: const TextStyle(color: Colors.white, fontSize: 20),
          ),
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final int score;
  final int total;
  const ResultScreen({super.key, required this.score, required this.total});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Results')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Score: $score / $total',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false);
                },
                child: const Text('Back to Categories'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

