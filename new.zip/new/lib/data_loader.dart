import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class DataLoader {
  static Future<List<dynamic>> loadCategories() async {
    final raw = await rootBundle.loadString('assets/quotes.json');
    final data = json.decode(raw);
    return (data['categories'] as List).toList();
  }
}

class QuoteData {
  final String category;
  final String branch;
  final Map<String, String> quote;
  final String hint;
  final String answer;

  QuoteData({
    required this.category,
    required this.branch,
    required this.quote,
    required this.hint,
    required this.answer,
  });

  factory QuoteData.fromJson(Map<String, dynamic> json) {
    return QuoteData(
      category: json['category'],
      branch: json['branch'],
      quote: Map<String, String>.from(json['quote']),
      hint: json['hint'],
      answer: json['answer'],
    );
  }
}

Future<List<QuoteData>> loadQuotes() async {
  final String response = await rootBundle.loadString('assets/quotes.json');
  final data = json.decode(response) as List;
  return data.map((e) => QuoteData.fromJson(e)).toList();
}


