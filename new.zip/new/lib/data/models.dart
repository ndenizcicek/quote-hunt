class Category {
  final String id;
  final String name;

  Category({required this.id, required this.name});

  factory Category.fromJson(Map<String, dynamic> json) =>
      Category(id: json['id'] ?? json['name'] ?? '', name: json['name'] ?? '');

  Map<String, dynamic> toJson() => {'id': id, 'name': name};
}

class QuoteItem {
  final String quote;
  final String answer;
  final String? hint;

  QuoteItem({required this.quote, required this.answer, this.hint});

  factory QuoteItem.fromJson(Map<String, dynamic> json) => QuoteItem(
        quote: json['quote'] ?? '',
        answer: json['answer'] ?? '',
        hint: json['hint'],
      );

  Map<String, dynamic> toJson() => {'quote': quote, 'answer': answer, 'hint': hint};
}

